# نشر موقع وهاج على Netlify

الموقع ليس ثقيلًا. حجم ملفات المصدر بدون `node_modules` و`.next` حوالي 1MB فقط.

المشكلة غالبًا تحدث عند رفع مجلد المشروع كاملًا يدويًا وفيه:

- `node_modules`
- `.next`
- ملفات log
- `tsconfig.tsbuildinfo`
- مجلد `artifacts`

هذه الملفات لا يجب رفعها. Netlify يبنيها بنفسه.

## الطريقة الصحيحة

الأفضل نشر المشروع عبر GitHub ثم ربطه مع Netlify:

1. ارفعي ملفات المشروع إلى GitHub.
2. في Netlify اختاري `Add new site`.
3. اختاري `Import an existing project`.
4. اربطي مستودع GitHub.
5. تأكدي أن الإعدادات هي:

```txt
Build command: npm run build
Publish directory: .next
Node version: 22
```

تمت إضافة هذه الإعدادات في `netlify.toml`.

## لا تستخدمي Drag & Drop للمجلد كاملًا

السحب والإفلات في Netlify مناسب غالبًا للمواقع الثابتة الجاهزة، وليس مشروع Next.js كامل فيه:

- API routes
- Admin authentication
- Proxy middleware
- Next image optimization

لذلك لا ترفعي المشروع كملف عادي في Netlify Drop.

## الملفات التي ترفعينها للمستودع

ارفعي هذه:

- `app`
- `components`
- `lib`
- `public`
- `package.json`
- `package-lock.json`
- `next.config.mjs`
- `netlify.toml`
- `postcss.config.mjs`
- `tailwind.config.ts`
- `tsconfig.json`
- `.env.example`

لا ترفعي هذه:

- `node_modules`
- `.next`
- `.env`
- `artifacts`
- `*.log`
- `*.tsbuildinfo`

## متغيرات البيئة على Netlify

من Netlify:

`Site configuration` -> `Environment variables`

أضيفي:

```txt
WAHAJ_ADMIN_EMAIL
WAHAJ_ADMIN_PASSWORD
WAHAJ_AUTH_SECRET
NEXT_PUBLIC_SUPABASE_URL
NEXT_PUBLIC_SUPABASE_ANON_KEY
SUPABASE_SERVICE_ROLE_KEY
CLOUDINARY_CLOUD_NAME
CLOUDINARY_API_KEY
CLOUDINARY_API_SECRET
```

إذا لم تستخدمي Supabase وCloudinary بعد، يمكن تركها فارغة مؤقتًا، لكن يجب تغيير بيانات الأدمن قبل الإطلاق.

## اختبار محلي قبل الرفع

```bash
npm install
npm run build
```

إذا نجح البناء محليًا، فالمشروع جاهز للنشر على Netlify.
