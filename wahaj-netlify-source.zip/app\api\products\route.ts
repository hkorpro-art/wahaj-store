import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { products } from "@/lib/data";
import { verifyAdminToken } from "@/lib/auth";
import { productInputSchema } from "@/lib/validation";

export async function GET() {
  return NextResponse.json({ products });
}

export async function POST(request: Request) {
  const token = (await cookies()).get("wahaj_admin")?.value;
  const admin = await verifyAdminToken(token);

  if (!admin) {
    return NextResponse.json({ message: "غير مصرح." }, { status: 401 });
  }

  const payload = productInputSchema.safeParse(await request.json());

  if (!payload.success) {
    return NextResponse.json({ message: "بيانات المنتج غير صالحة." }, { status: 400 });
  }

  return NextResponse.json(
    {
      message: "تم قبول المنتج. اربطي هذه النقطة بجدول Supabase production_products عند الإطلاق.",
      product: payload.data
    },
    { status: 201 }
  );
}
