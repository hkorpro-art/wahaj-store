import type { Metadata } from "next";
import { notFound } from "next/navigation";
import ProductDetailClient from "@/components/storefront/ProductDetailClient";
import { products } from "@/lib/data";

type ProductPageProps = {
  params: Promise<{
    slug: string;
  }>;
};

export function generateStaticParams() {
  return products.map((product) => ({
    slug: product.slug
  }));
}

export async function generateMetadata({ params }: ProductPageProps): Promise<Metadata> {
  const { slug } = await params;
  const product = products.find((item) => item.slug === slug);

  if (!product) {
    return {
      title: "قطعة غير متوفرة | وهاج"
    };
  }

  return {
    title: `${product.name} | وهاج`,
    description: product.description,
    openGraph: {
      title: `${product.name} | WAHAJ`,
      description: product.description,
      images: [product.images[0]]
    }
  };
}

export default async function ProductPage({ params }: ProductPageProps) {
  const { slug } = await params;
  const product = products.find((item) => item.slug === slug);

  if (!product) {
    notFound();
  }

  const similarProducts = products
    .filter((item) => item.category === product.category && item.id !== product.id)
    .slice(0, 4);

  return <ProductDetailClient product={product} similarProducts={similarProducts} />;
}
