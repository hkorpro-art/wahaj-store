"use client";

import { motion } from "framer-motion";
import {
  AlertTriangle,
  BadgePercent,
  BarChart3,
  Bell,
  CalendarClock,
  CircleDollarSign,
  Copy,
  Eye,
  FileText,
  GripVertical,
  ImageIcon,
  LayoutDashboard,
  LogOut,
  MessageCircle,
  PackageCheck,
  PackagePlus,
  Search,
  Send,
  Settings2,
  ShieldCheck,
  ShoppingBag,
  Sparkles,
  Tags,
  TrendingUp,
  UploadCloud,
  UsersRound,
  WandSparkles
} from "lucide-react";
import { useMemo, useState, type ComponentType, type DragEvent, type ReactNode } from "react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip as RechartsTooltip,
  XAxis,
  YAxis
} from "recharts";
import { analytics, coupons, customers, formatPrice, orders as seedOrders, products as seedProducts, stories } from "@/lib/data";
import type { Order, OrderStatus, Product } from "@/lib/types";

const tabs = [
  { id: "overview", label: "الرئيسية", icon: LayoutDashboard },
  { id: "products", label: "المنتجات", icon: PackagePlus },
  { id: "orders", label: "الطلبات", icon: ShoppingBag },
  { id: "customers", label: "العملاء", icon: UsersRound },
  { id: "coupons", label: "الكوبونات", icon: BadgePercent },
  { id: "content", label: "الموقع", icon: Settings2 },
  { id: "notifications", label: "الإشعارات", icon: Bell },
  { id: "analytics", label: "التحليلات", icon: BarChart3 },
  { id: "ai", label: "AI", icon: WandSparkles }
] as const;

type TabId = (typeof tabs)[number]["id"];

const statusClass: Record<OrderStatus, string> = {
  جديد: "bg-wahaj-warning/16 text-wahaj-ink border-wahaj-warning/35",
  "تم التواصل": "bg-wahaj-soft text-wahaj-rose border-wahaj-primary/40",
  مؤكد: "bg-wahaj-success/18 text-wahaj-ink border-wahaj-success/35",
  "تم التسليم": "bg-emerald-50 text-emerald-700 border-emerald-200",
  ملغي: "bg-red-50 text-red-700 border-red-200"
};

const chartColors = ["#D89CA4", "#B76E79", "#E0B56A", "#8FAF9A", "#D8A48F"];

export default function AdminDashboard() {
  const [activeTab, setActiveTab] = useState<TabId>("overview");
  const [products, setProducts] = useState<Product[]>(seedProducts);
  const [orders, setOrders] = useState<Order[]>(seedOrders);
  const [search, setSearch] = useState("");
  const [dropLabel, setDropLabel] = useState("اسحبي الصور هنا");

  const filteredProducts = useMemo(() => {
    return products.filter((product) => product.name.includes(search) || product.tags.some((tag) => tag.includes(search)));
  }, [products, search]);

  const lowStock = products.filter((product) => product.stock <= 8);
  const topViewed = [...products].sort((a, b) => b.views - a.views).slice(0, 5);
  const topSold = [...products].sort((a, b) => b.sold - a.sold).slice(0, 5);

  function duplicateProduct(product: Product) {
    const timestamp = Date.now();
    setProducts((current) => [
      {
        ...product,
        id: `${product.id}-${timestamp}`,
        slug: `${product.slug}-copy-${timestamp}`,
        name: `${product.name} نسخة`,
        stock: Math.max(product.stock, 1)
      },
      ...current
    ]);
  }

  function updateOrderStatus(orderId: string, status: OrderStatus) {
    setOrders((current) => current.map((order) => (order.id === orderId ? { ...order, status } : order)));
  }

  function handleDrop(event: DragEvent<HTMLDivElement>) {
    event.preventDefault();
    const files = Array.from(event.dataTransfer.files);
    setDropLabel(files.length > 0 ? `${files.length} صورة جاهزة للضغط والرفع` : "اسحبي الصور هنا");
  }

  async function logout() {
    await fetch("/api/admin/logout", { method: "POST" });
    window.location.href = "/admin/login";
  }

  return (
    <main className="min-h-screen bg-[#FFFCFA] text-wahaj-text">
      <div className="flex min-h-screen">
        <aside className="hidden w-72 shrink-0 border-l border-wahaj-border bg-white/86 p-4 backdrop-blur-xl lg:block">
          <AdminBrand />
          <nav className="mt-6 space-y-1">
            {tabs.map((tab) => (
              <TabButton key={tab.id} tab={tab} active={activeTab === tab.id} onClick={() => setActiveTab(tab.id)} />
            ))}
          </nav>
          <div className="mt-6 rounded-[8px] border border-wahaj-border bg-wahaj-card p-4">
            <ShieldCheck className="h-6 w-6 text-wahaj-success" />
            <p className="mt-3 font-bold text-wahaj-ink">حماية مفعلة</p>
            <p className="mt-1 text-sm leading-6 text-wahaj-text/70">JWT HttpOnly، تحقق مدخلات، وAPI محمي للمدير.</p>
          </div>
        </aside>

        <section className="min-w-0 flex-1">
          <header className="sticky top-0 z-30 border-b border-wahaj-border bg-white/78 backdrop-blur-2xl">
            <div className="flex items-center justify-between gap-3 px-4 py-3 lg:px-6">
              <div>
                <p className="text-sm text-wahaj-rose">لوحة تحكم وهاج</p>
                <h1 className="font-thmanyah text-2xl font-bold text-wahaj-ink">
                  {tabs.find((tab) => tab.id === activeTab)?.label}
                </h1>
              </div>
              <div className="flex items-center gap-2">
                <label className="hidden h-11 items-center gap-2 rounded-full border border-wahaj-border bg-white px-4 md:flex">
                  <Search className="h-4 w-4 text-wahaj-rose" />
                  <input
                    value={search}
                    onChange={(event) => setSearch(event.target.value)}
                    placeholder="بحث سريع"
                    className="w-48 bg-transparent text-sm outline-none"
                  />
                </label>
                <button className="flex h-11 w-11 items-center justify-center rounded-full border border-wahaj-border bg-white text-wahaj-rose">
                  <Bell className="h-5 w-5" />
                </button>
                <button
                  onClick={logout}
                  className="flex h-11 w-11 items-center justify-center rounded-full border border-wahaj-border bg-white text-wahaj-rose"
                  aria-label="تسجيل الخروج"
                >
                  <LogOut className="h-5 w-5" />
                </button>
              </div>
            </div>
            <div className="flex gap-2 overflow-x-auto px-4 pb-3 hide-scrollbar lg:hidden">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex min-w-fit items-center gap-2 rounded-full border px-3 py-2 text-sm font-bold ${
                    activeTab === tab.id
                      ? "border-wahaj-rose bg-wahaj-soft text-wahaj-rose"
                      : "border-wahaj-border bg-white"
                  }`}
                >
                  <tab.icon className="h-4 w-4" />
                  {tab.label}
                </button>
              ))}
            </div>
          </header>

          <div className="p-4 lg:p-6">
            {activeTab === "overview" ? (
              <Overview products={products} orders={orders} lowStock={lowStock} topViewed={topViewed} topSold={topSold} />
            ) : null}
            {activeTab === "products" ? (
              <ProductsManager
                products={filteredProducts}
                onDuplicate={duplicateProduct}
                dropLabel={dropLabel}
                onDrop={handleDrop}
              />
            ) : null}
            {activeTab === "orders" ? <OrdersManager orders={orders} onStatus={updateOrderStatus} /> : null}
            {activeTab === "customers" ? <CustomersManager /> : null}
            {activeTab === "coupons" ? <CouponsManager /> : null}
            {activeTab === "content" ? <ContentManager products={products} /> : null}
            {activeTab === "notifications" ? <NotificationsManager /> : null}
            {activeTab === "analytics" ? <AnalyticsManager topViewed={topViewed} topSold={topSold} /> : null}
            {activeTab === "ai" ? <AiAssistant /> : null}
          </div>
        </section>
      </div>
    </main>
  );
}

function AdminBrand() {
  return (
    <div className="rounded-[8px] bg-wahaj-ink p-4 text-white shadow-soft">
      <div className="flex items-center gap-3">
        <span className="flex h-12 w-12 items-center justify-center rounded-full bg-white/12">
          <Sparkles className="h-6 w-6 text-wahaj-stars" />
        </span>
        <div>
          <p className="font-thmanyah text-2xl font-bold">وهاج</p>
          <p className="text-xs text-white/68">WAHAJ Admin OS</p>
        </div>
      </div>
    </div>
  );
}

function TabButton({
  tab,
  active,
  onClick
}: {
  tab: (typeof tabs)[number];
  active: boolean;
  onClick: () => void;
}) {
  const Icon = tab.icon;
  return (
    <button
      onClick={onClick}
      className={`flex w-full items-center gap-3 rounded-[8px] px-3 py-3 text-sm font-bold transition ${
        active ? "bg-wahaj-soft text-wahaj-rose shadow-soft" : "text-wahaj-text hover:bg-wahaj-card"
      }`}
    >
      <Icon className="h-5 w-5" />
      {tab.label}
    </button>
  );
}

function Overview({
  products,
  orders,
  lowStock,
  topViewed,
  topSold
}: {
  products: Product[];
  orders: Order[];
  lowStock: Product[];
  topViewed: Product[];
  topSold: Product[];
}) {
  const cards = [
    { label: "عدد الطلبات", value: analytics.kpis.orders, icon: ShoppingBag, tone: "text-wahaj-rose" },
    { label: "المنتجات", value: products.length, icon: PackageCheck, tone: "text-wahaj-success" },
    { label: "الأرباح", value: formatPrice(analytics.kpis.revenue), icon: CircleDollarSign, tone: "text-wahaj-stars" },
    { label: "السلات المتروكة", value: `${analytics.kpis.abandonedCarts}%`, icon: AlertTriangle, tone: "text-wahaj-warning" }
  ];

  return (
    <div className="space-y-5">
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        {cards.map((card) => (
          <motion.div
            key={card.label}
            className="rounded-[8px] border border-wahaj-border bg-white p-4 shadow-soft"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <div className="flex items-center justify-between">
              <p className="text-sm text-wahaj-text/68">{card.label}</p>
              <card.icon className={`h-6 w-6 ${card.tone}`} />
            </div>
            <p className="mt-3 font-thmanyah text-2xl font-bold text-wahaj-ink">{card.value}</p>
          </motion.div>
        ))}
      </div>

      <QuickActions />

      <div className="grid gap-5 xl:grid-cols-[1.2fr_.8fr]">
        <Panel title="حركة المبيعات" icon={TrendingUp}>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={analytics.sales}>
                <defs>
                  <linearGradient id="salesGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#D89CA4" stopOpacity={0.5} />
                    <stop offset="95%" stopColor="#D89CA4" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid stroke="#E8D6D6" strokeDasharray="3 3" />
                <XAxis dataKey="day" tick={{ fill: "#6B4E4E", fontSize: 12 }} />
                <YAxis tick={{ fill: "#6B4E4E", fontSize: 12 }} width={44} />
                <RechartsTooltip />
                <Area type="monotone" dataKey="revenue" stroke="#B76E79" fill="url(#salesGradient)" strokeWidth={3} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Panel>

        <Panel title="أفضل الأقسام" icon={Tags}>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={analytics.categories} dataKey="value" nameKey="name" innerRadius={60} outerRadius={96} paddingAngle={4}>
                  {analytics.categories.map((entry, index) => (
                    <Cell key={entry.name} fill={chartColors[index % chartColors.length]} />
                  ))}
                </Pie>
                <RechartsTooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </Panel>
      </div>

      <div className="grid gap-5 xl:grid-cols-3">
        <Ranking title="الأكثر مبيعًا" products={topSold} metric="sold" />
        <Ranking title="الأكثر مشاهدة" products={topViewed} metric="views" />
        <Panel title="منخفضة المخزون" icon={AlertTriangle}>
          <div className="space-y-3">
            {lowStock.map((product) => (
              <div key={product.id} className="flex items-center justify-between rounded-[8px] bg-wahaj-card px-3 py-2">
                <span className="line-clamp-2 text-sm font-bold">{product.name}</span>
                <span className="rounded-full bg-white px-3 py-1 text-sm text-wahaj-rose">{product.stock}</span>
              </div>
            ))}
          </div>
        </Panel>
      </div>

      <Panel title="آخر الطلبات" icon={ShoppingBag}>
        <OrdersTable orders={orders.slice(0, 5)} compact />
      </Panel>
    </div>
  );
}

function QuickActions() {
  const actions = [
    { label: "إضافة منتج", icon: PackagePlus },
    { label: "إنشاء كوبون", icon: BadgePercent },
    { label: "إضافة عرض", icon: Tags },
    { label: "إضافة Story", icon: ImageIcon },
    { label: "إرسال إشعار", icon: Bell },
    { label: "تحديث المخزون", icon: PackageCheck }
  ];

  return (
    <Panel title="Quick Actions" icon={Sparkles}>
      <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
        {actions.map((action) => (
          <button
            key={action.label}
            className="flex min-h-24 flex-col items-center justify-center gap-2 rounded-[8px] border border-wahaj-border bg-wahaj-bg p-3 text-center font-bold transition hover:border-wahaj-rose hover:bg-wahaj-soft"
          >
            <action.icon className="h-6 w-6 text-wahaj-rose" />
            {action.label}
          </button>
        ))}
      </div>
    </Panel>
  );
}

function ProductsManager({
  products,
  onDuplicate,
  dropLabel,
  onDrop
}: {
  products: Product[];
  onDuplicate: (product: Product) => void;
  dropLabel: string;
  onDrop: (event: DragEvent<HTMLDivElement>) => void;
}) {
  return (
    <div className="grid gap-5 xl:grid-cols-[1fr_360px]">
      <Panel title="إدارة المنتجات" icon={PackagePlus}>
        <div className="overflow-x-auto admin-scrollbar">
          <table className="w-full min-w-[860px] text-sm">
            <thead>
              <tr className="border-b border-wahaj-border text-right text-wahaj-text/62">
                <th className="py-3">المنتج</th>
                <th>القسم</th>
                <th>السعر</th>
                <th>الخصم</th>
                <th>المخزون</th>
                <th>الحالات</th>
                <th>إجراءات</th>
              </tr>
            </thead>
            <tbody>
              {products.map((product) => (
                <tr key={product.id} className="border-b border-wahaj-border/70">
                  <td className="py-3">
                    <div className="flex items-center gap-3">
                      <span className="flex h-10 w-10 items-center justify-center rounded-[8px] bg-wahaj-card text-wahaj-rose">
                        <GripVertical className="h-5 w-5" />
                      </span>
                      <div>
                        <p className="font-bold text-wahaj-ink">{product.name}</p>
                        <p className="text-xs text-wahaj-text/55">{product.tags.join("، ")}</p>
                      </div>
                    </div>
                  </td>
                  <td>{product.category}</td>
                  <td className="font-bold text-wahaj-rose">{formatPrice(product.price)}</td>
                  <td>{product.compareAt ? formatPrice(product.compareAt - product.price) : "بدون"}</td>
                  <td>
                    <span className="rounded-full bg-wahaj-card px-3 py-1">{product.stock}</span>
                  </td>
                  <td>
                    <div className="flex flex-wrap gap-1">
                      {product.badges.map((badge) => (
                        <span key={badge} className="rounded-full border border-wahaj-border px-2 py-1 text-xs">
                          {badge}
                        </span>
                      ))}
                    </div>
                  </td>
                  <td>
                    <div className="flex gap-2">
                      <button
                        onClick={() => onDuplicate(product)}
                        className="flex h-9 w-9 items-center justify-center rounded-full border border-wahaj-border text-wahaj-rose"
                        aria-label="Duplicate Product"
                      >
                        <Copy className="h-4 w-4" />
                      </button>
                      <button className="flex h-9 w-9 items-center justify-center rounded-full border border-wahaj-border text-wahaj-rose">
                        <CalendarClock className="h-4 w-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Panel>

      <div className="space-y-5">
        <Panel title="إضافة منتج" icon={PackagePlus}>
          <div className="space-y-3">
            <input className="AdminInput" placeholder="اسم المنتج" />
            <div className="grid grid-cols-2 gap-2">
              <input className="AdminInput" placeholder="السعر" />
              <input className="AdminInput" placeholder="الخصم" />
            </div>
            <select className="AdminInput">
              <option>أطقم</option>
              <option>زركون</option>
              <option>أقراط</option>
              <option>أساور</option>
              <option>تيجان</option>
            </select>
            <textarea className="AdminInput min-h-28 py-3" placeholder="الوصف الفاخر" />
            <div
              onDrop={onDrop}
              onDragOver={(event) => event.preventDefault()}
              className="grid min-h-32 place-items-center rounded-[8px] border border-dashed border-wahaj-rose bg-wahaj-soft/45 p-4 text-center"
            >
              <div>
                <UploadCloud className="mx-auto h-7 w-7 text-wahaj-rose" />
                <p className="mt-2 font-bold">{dropLabel}</p>
                <p className="text-xs text-wahaj-text/60">Drag & Drop Upload، ضغط صور تلقائي، Cloudinary-ready</p>
              </div>
            </div>
            <button className="flex min-h-11 w-full items-center justify-center gap-2 rounded-full bg-wahaj-rose px-4 font-bold text-white">
              <PackagePlus className="h-5 w-5" />
              حفظ المنتج
            </button>
          </div>
        </Panel>

        <Panel title="مميزات سريعة" icon={Sparkles}>
          <div className="grid gap-2">
            {["Bulk Upload", "AI Product Description", "ضغط الصور تلقائيًا", "جدولة الخصومات"].map((item) => (
              <div key={item} className="flex items-center justify-between rounded-[8px] bg-wahaj-card px-3 py-2 text-sm font-bold">
                {item}
                <span className="rounded-full bg-white px-2 py-1 text-xs text-wahaj-rose">جاهز</span>
              </div>
            ))}
          </div>
        </Panel>
      </div>
    </div>
  );
}

function OrdersManager({ orders, onStatus }: { orders: Order[]; onStatus: (orderId: string, status: OrderStatus) => void }) {
  return (
    <Panel title="إدارة الطلبات" icon={ShoppingBag}>
      <OrdersTable orders={orders} onStatus={onStatus} />
    </Panel>
  );
}

function OrdersTable({
  orders,
  compact,
  onStatus
}: {
  orders: Order[];
  compact?: boolean;
  onStatus?: (orderId: string, status: OrderStatus) => void;
}) {
  const statuses: OrderStatus[] = ["جديد", "تم التواصل", "مؤكد", "تم التسليم", "ملغي"];

  return (
    <div className="overflow-x-auto admin-scrollbar">
      <table className="w-full min-w-[820px] text-sm">
        <thead>
          <tr className="border-b border-wahaj-border text-right text-wahaj-text/62">
            <th className="py-3">الطلب</th>
            <th>العميلة</th>
            <th>المنتجات</th>
            <th>الإجمالي</th>
            <th>الملاحظات</th>
            <th>الحالة</th>
            {!compact ? <th>واتساب</th> : null}
          </tr>
        </thead>
        <tbody>
          {orders.map((order) => (
            <tr key={order.id} className="border-b border-wahaj-border/70">
              <td className="py-3 font-bold text-wahaj-ink">{order.id}</td>
              <td>
                <p className="font-bold">{order.customer}</p>
                <p className="text-xs text-wahaj-text/55">{order.phone}</p>
              </td>
              <td className="max-w-64">
                <p className="line-clamp-2">{order.products.join("، ")}</p>
              </td>
              <td className="font-bold text-wahaj-rose">{formatPrice(order.total)}</td>
              <td>{order.notes}</td>
              <td>
                {onStatus ? (
                  <select
                    value={order.status}
                    onChange={(event) => onStatus(order.id, event.target.value as OrderStatus)}
                    className={`rounded-full border px-3 py-2 text-xs font-bold outline-none ${statusClass[order.status]}`}
                  >
                    {statuses.map((status) => (
                      <option key={status}>{status}</option>
                    ))}
                  </select>
                ) : (
                  <span className={`rounded-full border px-3 py-1 text-xs font-bold ${statusClass[order.status]}`}>
                    {order.status}
                  </span>
                )}
              </td>
              {!compact ? (
                <td>
                  <a
                    href={`https://wa.me/${order.phone.replace(/\D/g, "")}?text=${encodeURIComponent(
                      `مرحبًا ${order.customer} ✨\nمعك وهاج بخصوص طلبك ${order.id}.\nحالة الطلب: ${order.status}`
                    )}`}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex h-9 w-9 items-center justify-center rounded-full bg-wahaj-success text-white"
                  >
                    <MessageCircle className="h-4 w-4" />
                  </a>
                </td>
              ) : null}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function CustomersManager() {
  return (
    <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
      {customers.map((customer) => (
        <Panel key={customer.id} title={customer.name} icon={UsersRound}>
          <div className="space-y-3 text-sm">
            <div className="flex items-center justify-between">
              <span>الهاتف</span>
              <span className="font-bold">{customer.phone}</span>
            </div>
            <div className="flex items-center justify-between">
              <span>VIP</span>
              <span className={`rounded-full px-3 py-1 font-bold ${customer.vip ? "bg-wahaj-success/20" : "bg-wahaj-card"}`}>
                {customer.vip ? "نعم" : "لا"}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span>عدد الطلبات</span>
              <span className="font-bold">{customer.orders}</span>
            </div>
            <div className="flex items-center justify-between">
              <span>إجمالي الطلبات</span>
              <span className="font-bold text-wahaj-rose">{formatPrice(customer.total)}</span>
            </div>
            <div className="rounded-[8px] bg-wahaj-card p-3">
              <p className="font-bold text-wahaj-ink">احفظي للإلهام</p>
              <p className="mt-1 leading-6 text-wahaj-text/70">{customer.inspiration.join("، ")}</p>
            </div>
          </div>
        </Panel>
      ))}
    </div>
  );
}

function CouponsManager() {
  return (
    <div className="grid gap-5 xl:grid-cols-[1fr_360px]">
      <Panel title="الكوبونات" icon={BadgePercent}>
        <div className="grid gap-3 md:grid-cols-2">
          {coupons.map((coupon) => (
            <div key={coupon.id} className="rounded-[8px] border border-wahaj-border bg-wahaj-bg p-4">
              <div className="flex items-center justify-between">
                <p className="font-thmanyah text-2xl font-bold text-wahaj-ink">{coupon.code}</p>
                <span className="rounded-full bg-white px-3 py-1 text-sm font-bold text-wahaj-rose">
                  {coupon.type === "percentage" ? `${coupon.value}%` : formatPrice(coupon.value)}
                </span>
              </div>
              <div className="mt-4 grid gap-2 text-sm">
                <InfoRow label="تاريخ الانتهاء" value={coupon.expiresAt} />
                <InfoRow label="حد الاستخدام" value={coupon.usageLimit.toString()} />
                <InfoRow label="الحد الأدنى" value={formatPrice(coupon.minOrder)} />
              </div>
            </div>
          ))}
        </div>
      </Panel>
      <Panel title="إنشاء كوبون" icon={BadgePercent}>
        <div className="space-y-3">
          <input className="AdminInput" placeholder="CODE" />
          <select className="AdminInput">
            <option>نسبة خصم</option>
            <option>مبلغ ثابت</option>
          </select>
          <div className="grid grid-cols-2 gap-2">
            <input className="AdminInput" placeholder="القيمة" />
            <input className="AdminInput" placeholder="حد الاستخدام" />
          </div>
          <input className="AdminInput" placeholder="تاريخ انتهاء" />
          <input className="AdminInput" placeholder="حد أدنى للطلب" />
          <button className="min-h-11 w-full rounded-full bg-wahaj-rose px-4 font-bold text-white">حفظ الكوبون</button>
        </div>
      </Panel>
    </div>
  );
}

function ContentManager({ products }: { products: Product[] }) {
  return (
    <div className="grid gap-5 xl:grid-cols-2">
      <Panel title="البنرات والنصوص" icon={FileText}>
        <div className="space-y-3">
          <input className="AdminInput" defaultValue="تألقي بكل تفاصيلك" />
          <input className="AdminInput" defaultValue="لأنك تستحقين التألق" />
          <textarea className="AdminInput min-h-28 py-3" defaultValue="لمسات تصنع الفرق بلمعة زركون ناعمة." />
          <button className="min-h-11 rounded-full bg-wahaj-rose px-5 font-bold text-white">تحديث الواجهة</button>
        </div>
      </Panel>

      <Panel title="ترتيب المنتجات" icon={GripVertical}>
        <div className="space-y-2">
          {products.slice(0, 6).map((product, index) => (
            <div key={product.id} className="flex items-center justify-between rounded-[8px] bg-wahaj-card px-3 py-2">
              <div className="flex items-center gap-2">
                <GripVertical className="h-4 w-4 text-wahaj-rose" />
                <span className="text-sm font-bold">{product.name}</span>
              </div>
              <span className="rounded-full bg-white px-2 py-1 text-xs">{index + 1}</span>
            </div>
          ))}
        </div>
      </Panel>

      <Panel title="Stories" icon={ImageIcon}>
        <div className="grid gap-3 sm:grid-cols-2">
          {stories.map((story) => (
            <div key={story.id} className="rounded-[8px] border border-wahaj-border bg-wahaj-bg p-3">
              <p className="font-bold text-wahaj-ink">{story.title}</p>
              <div className="mt-2 flex gap-2">
                <button className="rounded-full bg-white px-3 py-1 text-xs font-bold">تعديل</button>
                <button className="rounded-full bg-white px-3 py-1 text-xs font-bold">إخفاء</button>
              </div>
            </div>
          ))}
        </div>
      </Panel>

      <Panel title="التكاملات" icon={ShieldCheck}>
        <div className="grid gap-2">
          {["Supabase Database", "Cloudinary Storage", "Secure APIs", "Input Validation", "SEO + Lazy Loading"].map((item) => (
            <div key={item} className="flex items-center justify-between rounded-[8px] bg-wahaj-card px-3 py-2 text-sm font-bold">
              {item}
              <span className="rounded-full bg-white px-2 py-1 text-xs text-wahaj-success">Ready</span>
            </div>
          ))}
        </div>
      </Panel>
    </div>
  );
}

function NotificationsManager() {
  const notificationTypes = ["عروض", "تخفيضات", "رجوع المخزون", "وصل حديثًا"];

  return (
    <div className="grid gap-5 xl:grid-cols-[360px_1fr]">
      <Panel title="إرسال إشعار" icon={Send}>
        <div className="space-y-3">
          <select className="AdminInput">
            {notificationTypes.map((type) => (
              <option key={type}>{type}</option>
            ))}
          </select>
          <input className="AdminInput" placeholder="عنوان الإشعار" />
          <textarea className="AdminInput min-h-32 py-3" placeholder="نص الإشعار" />
          <button className="flex min-h-11 w-full items-center justify-center gap-2 rounded-full bg-wahaj-rose font-bold text-white">
            <Send className="h-5 w-5" />
            إرسال
          </button>
        </div>
      </Panel>
      <Panel title="قوالب جاهزة" icon={Bell}>
        <div className="grid gap-3 md:grid-cols-2">
          {notificationTypes.map((type) => (
            <div key={type} className="rounded-[8px] border border-wahaj-border bg-wahaj-bg p-4">
              <p className="font-bold text-wahaj-ink">{type}</p>
              <p className="mt-2 text-sm leading-7 text-wahaj-text/70">
                قالب ناعم قابل للتعديل لإرسال إشعار {type} للعميلات المهتمات.
              </p>
            </div>
          ))}
        </div>
      </Panel>
    </div>
  );
}

function AnalyticsManager({ topViewed, topSold }: { topViewed: Product[]; topSold: Product[] }) {
  return (
    <div className="space-y-5">
      <div className="grid gap-5 xl:grid-cols-2">
        <Panel title="أوقات النشاط" icon={Eye}>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={analytics.activity}>
                <CartesianGrid stroke="#E8D6D6" strokeDasharray="3 3" />
                <XAxis dataKey="time" tick={{ fill: "#6B4E4E", fontSize: 12 }} />
                <YAxis tick={{ fill: "#6B4E4E", fontSize: 12 }} width={44} />
                <RechartsTooltip />
                <Bar dataKey="visits" fill="#B76E79" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Panel>
        <Panel title="معدل التحويل" icon={TrendingUp}>
          <div className="grid h-72 place-items-center">
            <div className="text-center">
              <p className="font-thmanyah text-6xl font-bold text-wahaj-rose">{analytics.kpis.conversion}%</p>
              <p className="mt-3 text-wahaj-text/70">تحويل زيارات المنتج إلى طلبات واتساب</p>
              <div className="mt-6 h-3 w-64 overflow-hidden rounded-full bg-wahaj-card">
                <div className="h-full rounded-full bg-wahaj-rose" style={{ width: `${analytics.kpis.conversion * 10}%` }} />
              </div>
            </div>
          </div>
        </Panel>
      </div>
      <div className="grid gap-5 xl:grid-cols-2">
        <Ranking title="أكثر المنتجات مشاهدة" products={topViewed} metric="views" />
        <Ranking title="الأكثر مبيعًا" products={topSold} metric="sold" />
      </div>
    </div>
  );
}

function AiAssistant() {
  const [type, setType] = useState("description");
  const [productName, setProductName] = useState("طقم لونا زركون روز");
  const [details, setDetails] = useState("قطعة روز قولد مناسبة للمناسبات");
  const [result, setResult] = useState("");
  const [loading, setLoading] = useState(false);

  async function generate() {
    setLoading(true);
    setResult("");
    const response = await fetch("/api/admin/ai", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ type, productName, details })
    });
    const payload = await response.json().catch(() => null);
    setLoading(false);
    setResult(payload?.result || payload?.message || "تعذر التوليد الآن.");
  }

  return (
    <div className="grid gap-5 xl:grid-cols-[380px_1fr]">
      <Panel title="مساعد وهاج AI" icon={WandSparkles}>
        <div className="space-y-3">
          <select value={type} onChange={(event) => setType(event.target.value)} className="AdminInput">
            <option value="description">توليد وصف المنتج</option>
            <option value="instagram">كتابة Caption انستقرام</option>
            <option value="whatsapp">نص واتساب تسويقي</option>
            <option value="pricing">اقتراح أسعار</option>
            <option value="image">تحسين الصور</option>
          </select>
          <input value={productName} onChange={(event) => setProductName(event.target.value)} className="AdminInput" />
          <textarea
            value={details}
            onChange={(event) => setDetails(event.target.value)}
            className="AdminInput min-h-32 py-3"
          />
          <button
            onClick={generate}
            disabled={loading}
            className="flex min-h-11 w-full items-center justify-center gap-2 rounded-full bg-wahaj-rose px-4 font-bold text-white disabled:opacity-60"
          >
            <WandSparkles className="h-5 w-5" />
            {loading ? "جار التوليد..." : "توليد"}
          </button>
        </div>
      </Panel>
      <Panel title="الناتج" icon={FileText}>
        <div className="min-h-72 rounded-[8px] border border-wahaj-border bg-wahaj-bg p-4 leading-8 text-wahaj-ink">
          {result || "سيظهر النص هنا بعد التوليد."}
        </div>
      </Panel>
    </div>
  );
}

function Ranking({ title, products, metric }: { title: string; products: Product[]; metric: "views" | "sold" }) {
  return (
    <Panel title={title} icon={metric === "views" ? Eye : TrendingUp}>
      <div className="space-y-3">
        {products.map((product, index) => (
          <div key={product.id} className="flex items-center gap-3 rounded-[8px] bg-wahaj-card px-3 py-2">
            <span className="flex h-8 w-8 items-center justify-center rounded-full bg-white font-bold text-wahaj-rose">
              {index + 1}
            </span>
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-bold text-wahaj-ink">{product.name}</p>
              <p className="text-xs text-wahaj-text/55">{metric === "views" ? "مشاهدة" : "مبيع"}</p>
            </div>
            <span className="font-bold text-wahaj-rose">{product[metric].toLocaleString("ar-YE")}</span>
          </div>
        ))}
      </div>
    </Panel>
  );
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <span className="text-wahaj-text/64">{label}</span>
      <span className="font-bold text-wahaj-ink">{value}</span>
    </div>
  );
}

function Panel({
  title,
  icon: Icon,
  children
}: {
  title: string;
  icon: ComponentType<{ className?: string }>;
  children: ReactNode;
}) {
  return (
    <section className="rounded-[8px] border border-wahaj-border bg-white p-4 shadow-soft">
      <div className="mb-4 flex items-center justify-between gap-3">
        <div>
          <h2 className="font-thmanyah text-xl font-bold text-wahaj-ink">{title}</h2>
        </div>
        <span className="flex h-10 w-10 items-center justify-center rounded-full bg-wahaj-soft text-wahaj-rose">
          <Icon className="h-5 w-5" />
        </span>
      </div>
      {children}
    </section>
  );
}
