import { z } from "zod";

export const productInputSchema = z.object({
  name: z.string().min(2).max(120),
  category: z.string().min(2).max(60),
  price: z.number().positive(),
  compareAt: z.number().positive().optional(),
  description: z.string().min(10).max(900),
  tags: z.array(z.string().min(1)).max(12).default([]),
  stock: z.number().int().min(0),
  images: z.array(z.string().url()).min(1).max(8)
});

export const orderInputSchema = z.object({
  customer: z.string().min(2).max(80),
  phone: z.string().min(7).max(24),
  products: z.array(z.string().min(1)).min(1),
  total: z.number().nonnegative(),
  notes: z.string().max(500).optional()
});

export const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8)
});

export const aiRequestSchema = z.object({
  type: z.enum(["description", "instagram", "whatsapp", "pricing", "image"]),
  productName: z.string().min(2).max(120),
  details: z.string().max(700).optional()
});
