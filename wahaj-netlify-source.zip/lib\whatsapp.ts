import { whatsappNumber } from "./data";
import type { CartItem, Product } from "./types";

export function buildCartMessage(items: CartItem[]) {
  const total = items.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const lines = items.map((item, index) => {
    return `${index + 1}. ${item.product.name}\nالكمية: ${item.quantity}\nالسعر: ${item.product.price.toLocaleString("ar-YE")} ر.ي`;
  });

  return [
    "مرحبًا وهاج ✨",
    "أرغب بطلب هذه القطع:",
    "",
    ...lines,
    "",
    `الإجمالي: ${total.toLocaleString("ar-YE")} ر.ي`,
    "الاسم:",
    "المدينة:",
    "ملاحظات:"
  ].join("\n");
}

export function buildSingleProductMessage(product: Product, quantity = 1) {
  const total = product.price * quantity;

  return [
    "مرحبًا وهاج ✨",
    "أرغب بحجز هذه القطعة:",
    product.name,
    `الكمية: ${quantity}`,
    `السعر: ${product.price.toLocaleString("ar-YE")} ر.ي`,
    `الإجمالي: ${total.toLocaleString("ar-YE")} ر.ي`,
    "الاسم:",
    "المدينة:",
    "ملاحظات:"
  ].join("\n");
}

export function whatsappUrl(message: string) {
  return `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(message)}`;
}
