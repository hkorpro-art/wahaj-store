module.exports=[37259,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_order-policy_page_actions_0xchnqf.js.map