var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/orders/route.js")
R.c("server/chunks/[root-of-the-server]__00ff93_._.js")
R.c("server/chunks/node_modules_next_124cnn1._.js")
R.c("server/chunks/[root-of-the-server]__0vxxedz._.js")
R.c("server/chunks/lib_0-46alc._.js")
R.c("server/chunks/_next-internal_server_app_api_orders_route_actions_0qla9fh.js")
R.m(81585)
module.exports=R.m(81585).exports
