var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/products/route.js")
R.c("server/chunks/[root-of-the-server]__06x8wpt._.js")
R.c("server/chunks/_06lsx54._.js")
R.c("server/chunks/[root-of-the-server]__0vxxedz._.js")
R.c("server/chunks/lib_0-46alc._.js")
R.c("server/chunks/node_modules_next_124cnn1._.js")
R.c("server/chunks/_next-internal_server_app_api_products_route_actions_0qlulka.js")
R.m(86577)
module.exports=R.m(86577).exports
