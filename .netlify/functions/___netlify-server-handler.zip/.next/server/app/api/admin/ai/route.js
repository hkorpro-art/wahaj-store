var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/ai/route.js")
R.c("server/chunks/[root-of-the-server]__12~fhfv._.js")
R.c("server/chunks/node_modules_next_124cnn1._.js")
R.c("server/chunks/[root-of-the-server]__0vxxedz._.js")
R.c("server/chunks/lib_0-46alc._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_ai_route_actions_0dihvd8.js")
R.m(26693)
module.exports=R.m(26693).exports
