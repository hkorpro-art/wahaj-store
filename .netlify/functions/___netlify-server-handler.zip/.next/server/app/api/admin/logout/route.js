var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/logout/route.js")
R.c("server/chunks/[root-of-the-server]__0lpgau7._.js")
R.c("server/chunks/[root-of-the-server]__0vxxedz._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_logout_route_actions_0lmnpyx.js")
R.m(82494)
module.exports=R.m(82494).exports
