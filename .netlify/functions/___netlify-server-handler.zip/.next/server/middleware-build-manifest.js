globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/H459iPsmt0s4xjtvt3mqp/_buildManifest.js",
    "static/H459iPsmt0s4xjtvt3mqp/_ssgManifest.js",
    "static/H459iPsmt0s4xjtvt3mqp/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0yb2wil16uz6h.js",
    "static/chunks/02.us7m76zsub.js",
    "static/chunks/001r8-v75rw5i.js",
    "static/chunks/10u3y4bw1ayzs.js",
    "static/chunks/0pqt~8bl3ukh4.js",
    "static/chunks/turbopack-12-jc~y8bb4eg.js"
  ]
};
