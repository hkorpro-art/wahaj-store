var R=require("./chunks/[turbopack]_runtime.js")("server/middleware.js")
R.c("server/chunks/[externals]__00r68~9._.js")
R.c("server/chunks/[root-of-the-server]__0891aj9._.js")
R.m(62395)
module.exports=R.m(62395).exports
